<script>

</script>

<style type="text/scss">
  h4 {
      text-align: center;
  }
</style>

<div class>
  <h4>Attributes info</h4>
  <table>
    <thead>
      <tr>
        <th>Feature</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>qty_dot_url</td>
        <td>count (.) in URL</td>
      </tr>
      <tr>
        <td>qty_hyphen_url</td>
        <td>count (-) in URL</td>
      </tr>
      <tr>
        <td>qty_underline_url</td>
        <td>count (_) in URL</td>
      </tr>
      <tr>
        <td>qty_slash_url</td>
        <td>count (/) in URL</td>
      </tr>
      <tr>
        <td>qty_questionmark_url</td>
        <td>count (?) in URL</td>
      </tr>
      <tr>
        <td>qty_equal_url</td>
        <td>count (=) in URL</td>
      </tr>
      <tr>
        <td>qty_at_url</td>
        <td>count (@) in URL</td>
      </tr>
      <tr>
        <td>qty_and_url</td>
        <td>count (&amp;) in URL</td>
      </tr>
      <tr>
        <td>qty_exclamation_url</td>
        <td>count (!) in URL</td>
      </tr>
      <tr>
        <td>qty_space_url</td>
        <td>count ( ) in URL</td>
      </tr>
      <tr>
        <td>qty_tilde_url</td>
        <td>count (~) in URL</td>
      </tr>
      <tr>
        <td>qty_comma_url</td>
        <td>count (,) in URL</td>
      </tr>
      <tr>
        <td>qty_plus_url</td>
        <td>count (+) in URL</td>
      </tr>
      <tr>
        <td>qty_asterisk_url</td>
        <td>count (*) in URL</td>
      </tr>
      <tr>
        <td>qty_hashtag_url</td>
        <td>count (#) in URL</td>
      </tr>
      <tr>
        <td>qty_dollar_url</td>
        <td>count ($) in URL</td>
      </tr>
      <tr>
        <td>qty_percent_url</td>
        <td>count (%) in URL</td>
      </tr>
      <tr>
        <td>qty_tld_url</td>
        <td>top-level-domain length</td>
      </tr>
      <tr>
        <td>length_url</td>
        <td>URL length</td>
      </tr>
      <tr>
        <td>qty_dot_domain</td>
        <td>count (.) in domain</td>
      </tr>
      <tr>
        <td>qty_hyphen_domain</td>
        <td>count (-) in domain</td>
      </tr>
      <tr>
        <td>qty_underline_domain</td>
        <td>count (_) in domain</td>
      </tr>
      <tr>
        <td>qty_slash_domain</td>
        <td>count (/) in domain</td>
      </tr>
      <tr>
        <td>qty_questionmark_domain</td>
        <td>count (?) in domain</td>
      </tr>
      <tr>
        <td>qty_equal_domain</td>
        <td>count (=) in domain</td>
      </tr>
      <tr>
        <td>qty_at_domain</td>
        <td>count (@) in domain</td>
      </tr>
      <tr>
        <td>qty_and_domain</td>
        <td>count (&amp;) in domain</td>
      </tr>
      <tr>
        <td>qty_exclamation_domain</td>
        <td>count (!) in domain</td>
      </tr>
      <tr>
        <td>qty_space_domain</td>
        <td>count ( ) in domain</td>
      </tr>
      <tr>
        <td>qty_tilde_domain</td>
        <td>count (~) in domain</td>
      </tr>
      <tr>
        <td>qty_comma_domain</td>
        <td>count (,) in domain</td>
      </tr>
      <tr>
        <td>qty_plus_domain</td>
        <td>count (+) in domain</td>
      </tr>
      <tr>
        <td>qty_asterisk_domain</td>
        <td>count (*) in domain</td>
      </tr>
      <tr>
        <td>qty_hashtag_domain</td>
        <td>count (#) in domain</td>
      </tr>
      <tr>
        <td>qty_dollar_domain</td>
        <td>count ($) in domain</td>
      </tr>
      <tr>
        <td>qty_percent_domain</td>
        <td>count (%) in domain</td>
      </tr>
      <tr>
        <td>qty_vowels_domain</td>
        <td>count vowels in domain</td>
      </tr>
      <tr>
        <td>domain_length</td>
        <td>domain length</td>
      </tr>
      <tr>
        <td>domain_in_ip</td>
        <td>URL domain in IP address format</td>
      </tr>
      <tr>
        <td>server_client_domain</td>
        <td>domain contains the keywords "server" or "client"</td>
      </tr>
      <tr>
        <td>qty_dot_directory</td>
        <td>count (.) in directory</td>
      </tr>
      <tr>
        <td>qty_hyphen_directory</td>
        <td>count (-) in directory</td>
      </tr>
      <tr>
        <td>qty_underline_directory</td>
        <td>count (_) in directory</td>
      </tr>
      <tr>
        <td>qty_slash_directory</td>
        <td>count (/) in directory</td>
      </tr>
      <tr>
        <td>qty_questionmark_directory</td>
        <td>count (?) in directory</td>
      </tr>
      <tr>
        <td>qty_equal_directory</td>
        <td>count (=) in directory</td>
      </tr>
      <tr>
        <td>qty_at_directory</td>
        <td>count (@) in directory</td>
      </tr>
      <tr>
        <td>qty_and_directory</td>
        <td>count (&amp;) in directory</td>
      </tr>
      <tr>
        <td>qty_exclamation_directory</td>
        <td>count (!) in directory</td>
      </tr>
      <tr>
        <td>qty_space_directory</td>
        <td>count ( ) in directory</td>
      </tr>
      <tr>
        <td>qty_tilde_directory</td>
        <td>count (~) in directory</td>
      </tr>
      <tr>
        <td>qty_comma_directory</td>
        <td>count (,) in directory</td>
      </tr>
      <tr>
        <td>qty_plus_directory</td>
        <td>count (+) in directory</td>
      </tr>
      <tr>
        <td>qty_asterisk_directory</td>
        <td>count (*) in directory</td>
      </tr>
      <tr>
        <td>qty_hashtag_directory</td>
        <td>count (#) in directory</td>
      </tr>
      <tr>
        <td>qty_dollar_directory</td>
        <td>count ($) in directory</td>
      </tr>
      <tr>
        <td>qty_percent_directory</td>
        <td>count (%) in directory</td>
      </tr>
      <tr>
        <td>directory_length</td>
        <td>directory length</td>
      </tr>
      <tr>
        <td>qty_dot_file</td>
        <td>count (.) in file</td>
      </tr>
      <tr>
        <td>qty_hyphen_file</td>
        <td>count (-) in file</td>
      </tr>
      <tr>
        <td>qty_underline_file</td>
        <td>count (_) in file</td>
      </tr>
      <tr>
        <td>qty_slash_file</td>
        <td>count (/) in file</td>
      </tr>
      <tr>
        <td>qty_questionmark_file</td>
        <td>count (?) in file</td>
      </tr>
      <tr>
        <td>qty_equal_file</td>
        <td>count (=) in file</td>
      </tr>
      <tr>
        <td>qty_at_file</td>
        <td>count (@) in file</td>
      </tr>
      <tr>
        <td>qty_and_file</td>
        <td>count (&amp;) in file</td>
      </tr>
      <tr>
        <td>qty_exclamation_file</td>
        <td>count (!) in file</td>
      </tr>
      <tr>
        <td>qty_space_file</td>
        <td>count ( ) in file</td>
      </tr>
      <tr>
        <td>qty_tilde_file</td>
        <td>count (~) in file</td>
      </tr>
      <tr>
        <td>qty_comma_file</td>
        <td>count (,) in file</td>
      </tr>
      <tr>
        <td>qty_plus_file</td>
        <td>count (+) in file</td>
      </tr>
      <tr>
        <td>qty_asterisk_file</td>
        <td>count (*) in file</td>
      </tr>
      <tr>
        <td>qty_hashtag_file</td>
        <td>count (#) in file</td>
      </tr>
      <tr>
        <td>qty_dollar_file</td>
        <td>count ($) in file</td>
      </tr>
      <tr>
        <td>qty_percent_file</td>
        <td>count (%) in file</td>
      </tr>
      <tr>
        <td>file_length</td>
        <td>file length</td>
      </tr>
      <tr>
        <td>qty_dot_params</td>
        <td>count (.) in parameters</td>
      </tr>
      <tr>
        <td>qty_hyphen_params</td>
        <td>count (-) in parameters</td>
      </tr>
      <tr>
        <td>qty_underline_params</td>
        <td>count (_) in parameters</td>
      </tr>
      <tr>
        <td>qty_slash_params</td>
        <td>count (/) in parameters</td>
      </tr>
      <tr>
        <td>qty_questionmark_params</td>
        <td>count (?) in parameters</td>
      </tr>
      <tr>
        <td>qty_equal_params</td>
        <td>count (=) in parameters</td>
      </tr>
      <tr>
        <td>qty_at_params</td>
        <td>count (@) in parameters</td>
      </tr>
      <tr>
        <td>qty_and_params</td>
        <td>count (&amp;) in parameters</td>
      </tr>
      <tr>
        <td>qty_exclamation_params</td>
        <td>count (!) in parameters</td>
      </tr>
      <tr>
        <td>qty_space_params</td>
        <td>count ( ) in parameters</td>
      </tr>
      <tr>
        <td>qty_tilde_params</td>
        <td>count (~) in parameters</td>
      </tr>
      <tr>
        <td>qty_comma_params</td>
        <td>count (,) in parameters</td>
      </tr>
      <tr>
        <td>qty_plus_params</td>
        <td>count (+) in parameters</td>
      </tr>
      <tr>
        <td>qty_asterisk_params</td>
        <td>count (*) in parameters</td>
      </tr>
      <tr>
        <td>qty_hashtag_params</td>
        <td>count (#) in parameters</td>
      </tr>
      <tr>
        <td>qty_dollar_params</td>
        <td>count ($) in parameters</td>
      </tr>
      <tr>
        <td>qty_percent_params</td>
        <td>count (%) in parameters</td>
      </tr>
      <tr>
        <td>params_length</td>
        <td>parameters length</td>
      </tr>
      <tr>
        <td>tld_present_params</td>
        <td>TLD presence in arguments</td>
      </tr>
      <tr>
        <td>qty_params</td>
        <td>number of parameters</td>
      </tr>
      <tr>
        <td>email_in_url</td>
        <td>email present in URL</td>
      </tr>
      <tr>
        <td>time_response</td>
        <td>search time (response) domain (lookup)</td>
      </tr>
      <tr>
        <td>domain_spf</td>
        <td>domain has SPF</td>
      </tr>
      <tr>
        <td>asn_ip</td>
        <td>AS Number (or ASN)</td>
      </tr>
      <tr>
        <td>time_domain_activation</td>
        <td>time (in days) of domain activation</td>
      </tr>
      <tr>
        <td>time_domain_expiration</td>
        <td>time (in days) of domain expiration</td>
      </tr>
      <tr>
        <td>qty_ip_resolved</td>
        <td>number of resolved IPs</td>
      </tr>
      <tr>
        <td>qty_nameservers</td>
        <td>number of resolved name servers (NameServers - NS)</td>
      </tr>
      <tr>
        <td>qty_mx_servers</td>
        <td>number of MX Servers</td>
      </tr>
      <tr>
        <td>ttl_hostname</td>
        <td>time-to-live (TTL) value associated with hostname</td>
      </tr>
      <tr>
        <td>tls_ssl_certificate</td>
        <td>valid TLS / SSL Certificate</td>
      </tr>
      <tr>
        <td>qty_redirects</td>
        <td>number of redirects</td>
      </tr>
      <tr>
        <td>url_google_index</td>
        <td>check if URL is indexed on Google</td>
      </tr>
      <tr>
        <td>domain_google_index</td>
        <td>check if domain is indexed on Google</td>
      </tr>
      <tr>
        <td>url_shortened</td>
        <td>check if URL is shortened</td>
      </tr>
      <tr>
        <td>phishing</td>
        <td>is phishing website</td>
      </tr>
    </tbody>
  </table>
</div>
