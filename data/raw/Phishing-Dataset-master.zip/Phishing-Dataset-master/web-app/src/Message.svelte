<script>
    export let message;
  </script>

  <p>
    {message}
  </p>